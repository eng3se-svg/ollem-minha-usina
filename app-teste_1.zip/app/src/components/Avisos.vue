<script setup>
// Central de avisos (sino): o que precisa de atenção agora + o que já chegou
import { computed, onMounted, ref } from 'vue'
import { estado, usinas, modoDemo } from '../store'
import { resumo } from '../lib/calc'
import { api } from '../api'

const emit = defineEmits(['fechar'])
const doServidor = ref([])
const carregando = ref(!modoDemo)

// Agora: alertas calculados de todas as usinas do cliente
const agora = computed(() => usinas.flatMap((u, i) =>
  resumo(u).alertas.map(a => ({ ...a, idx: i, usina: `Usina em ${u.bairro}`, chave: `${u.id}:${a.titulo}` }))))

// Antes: histórico (demo = exemplos; real = /avisos do servidor)
const exemplos = [
  { tipo: 'relatorio', titulo: 'Seu relatório de outubro está pronto', texto: 'Toque para abrir o PDF com a geração e a economia do mês.', quando: '1 nov' },
  { tipo: 'economia', titulo: 'Em outubro você economizou R$ 932', texto: 'A usina gerou 101% do esperado no mês. Muito bom!', quando: '1 nov' },
  { tipo: 'visita', titulo: 'Limpeza das placas concluída', texto: 'A equipe da Ollem passou por aí. A geração deve subir nos próximos dias.', quando: '22 out' }
]
const antes = computed(() => {
  const pedidos = estado.pedidos.map(p => ({ tipo: 'pedido', titulo: `${p.tipo}: ${p.status.toLowerCase()}`, texto: 'A Ollem vai responder por aqui e no WhatsApp.', quando: p.quando }))
  return modoDemo ? [...pedidos, ...exemplos] : doServidor.value
})

const quando = iso => {
  if (!iso) return ''
  const d = new Date(iso.replace(' ', 'T'))
  return isNaN(d) ? iso : d.toLocaleDateString('pt-BR', { day: 'numeric', month: 'short' }).replace('.', '')
}

onMounted(async () => {
  estado.avisosLidos = agora.value.map(a => a.chave)
  if (modoDemo) return
  try {
    const r = await api.avisos()
    doServidor.value = (r.avisos || []).map(a => ({ ...a, quando: quando(a.criado) }))
    api.avisosLidos().catch(() => {})
  } catch { /* sem conexão: mostra só os alertas de agora */ }
  carregando.value = false
})

const abrir = a => {
  estado.usinaIdx = a.idx
  estado.servico = a.acao === 'ollivia' ? 'chat' : 'pedido'
  estado.aba = 'ajuda'
  emit('fechar')
}
const ic = {
  relatorio: 'M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h6',
  economia: 'M12 2v20M17 6H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6',
  visita: 'M5 12l5 5L20 7',
  pedido: 'M4 6h16M4 12h16M4 18h10'
}
</script>

<template>
  <div class="fundo-folha" @click.self="emit('fechar')">
    <div class="folha" role="dialog" aria-label="Avisos">
      <span class="pegador"></span>
      <div class="topo"><b class="h">Avisos</b><button class="x" @click="emit('fechar')" aria-label="Fechar">✕</button></div>

      <small class="sec">Agora</small>
      <div v-if="!agora.length" class="tudo-ok">
        <span><svg viewBox="0 0 24 24"><path d="M5 12l5 5L20 7" /></svg></span>
        <div><b>Tudo certo com {{ usinas.length > 1 ? 'as suas usinas' : 'a sua usina' }}</b><p>Se algo acontecer, você fica sabendo aqui primeiro.</p></div>
      </div>
      <button v-for="a in agora" :key="a.chave" class="av" :class="a.nivel" @click="abrir(a)">
        <i></i>
        <div>
          <b>{{ a.titulo }}</b>
          <small v-if="usinas.length > 1">{{ a.usina }}</small>
          <p>{{ a.texto }}</p>
          <em>{{ a.acao === 'ollivia' ? 'Falar com a Ollivia ›' : 'Solicitar limpeza ou visita ›' }}</em>
        </div>
      </button>

      <small class="sec">Anteriores</small>
      <p v-if="carregando" class="vazio">Carregando…</p>
      <p v-else-if="!antes.length" class="vazio">Nenhum aviso por enquanto.</p>
      <div v-for="(a, i) in antes" :key="i" class="velho">
        <span><svg viewBox="0 0 24 24"><path :d="ic[a.tipo] || ic.pedido" /></svg></span>
        <div><b>{{ a.titulo }}</b><p>{{ a.texto }}</p></div>
        <time>{{ a.quando }}</time>
      </div>
    </div>
  </div>
</template>

<style scoped>
.fundo-folha { position: absolute; inset: 0; z-index: 40; background: rgba(0,0,0,.35); display: flex; align-items: flex-end; justify-content: center; }
.folha { width: 100%; max-height: 86%; overflow-y: auto; background: var(--card); color: var(--texto); border-radius: 26px 26px 0 0; padding: 10px 20px 28px; display: flex; flex-direction: column; gap: 10px; scrollbar-width: none; }
.folha::-webkit-scrollbar { display: none; }
.pegador { width: 38px; height: 4px; border-radius: 4px; background: var(--linha); align-self: center; flex: none; }
.topo { display: flex; align-items: center; justify-content: space-between; }
.h { font-size: 18px; }
.x { width: 32px; height: 32px; border-radius: 50%; border: 0; background: var(--trilho); color: var(--sub); font-size: 13px; }
.sec { font-size: 11.5px; font-weight: 600; color: var(--sub); text-transform: uppercase; letter-spacing: .04em; margin-top: 4px; }
.tudo-ok, .velho { display: flex; gap: 12px; align-items: flex-start; }
.tudo-ok { background: var(--trilho); border-radius: 16px; padding: 12px 14px; }
.tudo-ok span, .velho span { flex: none; width: 34px; height: 34px; border-radius: 50%; display: grid; place-items: center; background: color-mix(in srgb, var(--verde) 16%, transparent); }
.velho span { background: var(--trilho); }
svg { width: 17px; height: 17px; fill: none; stroke: var(--acento); stroke-width: 1.9; stroke-linecap: round; stroke-linejoin: round; }
.velho svg { stroke: var(--sub); }
b { font-size: 14px; font-weight: 600; display: block; }
p { margin: 2px 0 0; font-size: 12.5px; line-height: 1.4; color: var(--sub); }
.av { display: flex; gap: 12px; text-align: left; border: 1px solid var(--linha); background: var(--fundo); color: var(--texto); border-radius: 16px; padding: 12px 14px; font: inherit; width: 100%; }
.av i { flex: none; width: 9px; height: 9px; border-radius: 50%; margin-top: 5px; background: var(--ambar); }
.av.alta i { background: var(--vermelho); box-shadow: 0 0 0 4px color-mix(in srgb, var(--vermelho) 18%, transparent); }
.av small { font-size: 11.5px; color: var(--sub); }
.av em { display: block; margin-top: 6px; font-style: normal; font-size: 13px; font-weight: 600; color: var(--acento); }
.av:active { transform: scale(.98); }
.velho { padding: 4px 0; }
.velho div { flex: 1; min-width: 0; }
time { font-size: 11.5px; color: var(--sub); white-space: nowrap; }
.vazio { font-size: 13px; }
</style>
