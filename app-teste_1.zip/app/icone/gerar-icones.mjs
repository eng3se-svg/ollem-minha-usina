// Gera as imagens-base do ícone e da abertura a partir do símbolo (SVG) e chama o @capacitor/assets
import sharp from 'sharp'
import { mkdirSync, readFileSync } from 'fs'
const svg = readFileSync(new URL("./simbolo.svg", import.meta.url))
const FUNDO = '#0c100e'
mkdirSync("assets", { recursive: true })
const simb = h => sharp(svg, { density: 600 }).resize({ height: h }).png().toBuffer()
const tela = async (lado, h, fundo, nome) => sharp({ create: { width: lado, height: lado, channels: 4, background: fundo } })
  .composite([{ input: await simb(h), gravity: 'center' }]).png().toFile('assets/' + nome)
await tela(1024, 600, FUNDO, 'icon-only.png')
await tela(1024, 520, { r: 0, g: 0, b: 0, alpha: 0 }, 'icon-foreground.png')
await sharp({ create: { width: 1024, height: 1024, channels: 4, background: FUNDO } }).png().toFile('assets/icon-background.png')
await tela(2732, 520, FUNDO, 'splash.png')
await tela(2732, 520, FUNDO, 'splash-dark.png')
console.log('imagens-base prontas')
